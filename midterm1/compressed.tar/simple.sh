#!/bin/bash
#Simple Script
echo Congratulations! Now you know shell script!
echo -n "The current time and date are: "
date

